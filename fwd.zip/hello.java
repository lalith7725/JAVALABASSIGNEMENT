//week1
import java.util.Scanner;
class hello{
    public static void main(String[] args){
        Scanner scn=new Scanner(System.in);
        System.out.println("enter a:");
        
        int a=scn.nextInt();
        System.out.println("enter b:");
        int b=scn.nextInt();
        int sum=a+b;
        System.out.println("sum:"+sum);
      
        scn.close();

        }
        
    
}